"""
FastAPI application entry point.

- Loads the BART model ONCE at startup via the lifespan context manager
  (the modern replacement for @app.on_event, so a load failure is visible at boot).
- Adds CORS so the Flutter app can call it from another origin.
- Adds a middleware that stamps every response with an X-Process-Time header.
- Registers clean JSON error handlers.
- Exposes GET /health and POST /summarize (see routers/summarize.py).

Run:  uvicorn app.main:app --reload  --host 0.0.0.0 --port 8000
Docs: http://localhost:8000/docs
"""
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .config import settings
from .schemas import HealthResponse
from .summarizer import Summarizer
from .routers import summarize as summarize_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    # ---- Startup: load the model before the API accepts traffic ----
    print(f"[startup] Loading model '{settings.MODEL_NAME}' ...")
    summarizer = Summarizer()
    summarizer.load()
    app.state.summarizer = summarizer
    print(f"[startup] Model ready on device: {summarizer.device}")
    yield
    # ---- Shutdown: release the model ----
    app.state.summarizer = None
    print("[shutdown] Released model.")


app = FastAPI(
    title="Legal Document Summarization API",
    description="Abstractive summarization of legal/compliance text using facebook/bart-large-cnn.",
    version="1.0.0",
    lifespan=lifespan,
)

# ---- CORS: allow the Flutter client (web/mobile) to call this API ----------
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Process-Time"],
)


# ---- Middleware: add a timing header to every response --------------------
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start = time.perf_counter()
    response = await call_next(request)
    response.headers["X-Process-Time"] = f"{time.perf_counter() - start:.3f}"
    return response


# ---- Uniform JSON error responses ----------------------------------------
@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    # Last-resort catch so clients always get JSON, never an HTML stack trace.
    return JSONResponse(status_code=500, content={"detail": f"Internal server error: {exc}"})


# ---- Health check ---------------------------------------------------------
@app.get("/health", response_model=HealthResponse)
def health(request: Request) -> HealthResponse:
    summarizer = getattr(request.app.state, "summarizer", None)
    ready = bool(summarizer and summarizer.is_ready)
    return HealthResponse(
        status="healthy" if ready else "loading",
        model_loaded=ready,
        model_name=settings.MODEL_NAME,
        device=summarizer.device if summarizer else "unknown",
    )


@app.get("/")
def root():
    return {"service": "Legal Document Summarization API", "docs": "/docs", "health": "/health"}


# ---- Routes ---------------------------------------------------------------
app.include_router(summarize_router.router, tags=["summarization"])
