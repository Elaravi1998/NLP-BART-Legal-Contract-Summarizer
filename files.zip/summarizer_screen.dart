import 'package:flutter/material.dart';

import '../models/summary_result.dart';
import '../services/api_service.dart';

class SummarizerScreen extends StatefulWidget {
  const SummarizerScreen({super.key});

  @override
  State<SummarizerScreen> createState() => _SummarizerScreenState();
}

class _SummarizerScreenState extends State<SummarizerScreen> {
  final _controller = TextEditingController();
  final _api = ApiService();

  bool _loading = false;
  SummaryResult? _result;
  String? _error;

  @override
  void initState() {
    super.initState();
    // Rebuild on typing so the char count and button-enabled state stay in sync.
    _controller.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  bool get _hasText => _controller.text.trim().isNotEmpty;

  Future<void> _summarize() async {
    FocusScope.of(context).unfocus(); // dismiss the keyboard

    if (!_hasText) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please paste a legal document first.")),
      );
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
      _result = null;
    });

    try {
      final result = await _api.summarize(_controller.text.trim());
      setState(() => _result = result);
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = "Unexpected error: $e");
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _clear() {
    setState(() {
      _controller.clear();
      _result = null;
      _error = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Legal Document Summarizer"),
        backgroundColor: theme.colorScheme.primaryContainer,
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  "Paste a contract, policy, or compliance notice below and generate a concise summary.",
                  style: theme.textTheme.bodyMedium,
                ),
                const SizedBox(height: 12),

                // ---- Input field ----
                TextField(
                  controller: _controller,
                  minLines: 8,
                  maxLines: 16,
                  enabled: !_loading,
                  textAlignVertical: TextAlignVertical.top,
                  decoration: InputDecoration(
                    hintText: "Paste your legal document here…",
                    filled: true,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 8),

                // ---- Char count + Clear ----
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("${_controller.text.length} characters",
                        style: theme.textTheme.bodySmall),
                    TextButton.icon(
                      onPressed: _loading ? null : _clear,
                      icon: const Icon(Icons.clear, size: 18),
                      label: const Text("Clear"),
                    ),
                  ],
                ),
                const SizedBox(height: 8),

                // ---- Summarize button ----
                FilledButton.icon(
                  onPressed: (_loading || !_hasText) ? null : _summarize,
                  icon: _loading
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.auto_awesome),
                  label: Text(_loading ? "Summarizing…" : "Summarize"),
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
                const SizedBox(height: 20),

                // ---- Output area ----
                if (_error != null) _ErrorCard(message: _error!),
                if (_result != null) _ResultCard(result: _result!),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Red error card shown when a request fails.
class _ErrorCard extends StatelessWidget {
  final String message;
  const _ErrorCard({required this.message});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      color: theme.colorScheme.errorContainer,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.error_outline, color: theme.colorScheme.onErrorContainer),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                message,
                style: TextStyle(color: theme.colorScheme.onErrorContainer),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Summary + metadata card shown on success.
class _ResultCard extends StatelessWidget {
  final SummaryResult result;
  const _ResultCard({required this.result});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final hasUngrounded = result.faithfulness.ungrounded.isNotEmpty;

    return Card(
      elevation: 0,
      color: theme.colorScheme.surfaceContainerHighest,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.description, color: theme.colorScheme.primary),
                const SizedBox(width: 8),
                Text("Summary", style: theme.textTheme.titleMedium),
              ],
            ),
            const Divider(height: 20),

            // The generated summary text (selectable so it can be copied).
            SelectableText(result.summary, style: theme.textTheme.bodyLarge),
            const SizedBox(height: 16),

            // Metadata chips.
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _chip(context, Icons.compress,
                    "Compression ${result.compressionPercent}"),
                _chip(context, Icons.token,
                    "${result.inputTokens} → ${result.summaryTokens} tokens"),
                if (result.chunked)
                  _chip(context, Icons.view_agenda, "Long doc (chunked)"),
                _chip(
                  context,
                  hasUngrounded ? Icons.warning_amber : Icons.verified,
                  "Faithfulness ${result.faithfulnessPercent}",
                  warn: hasUngrounded,
                ),
              ],
            ),

            // Show any facts that weren't found in the source.
            if (hasUngrounded) ...[
              const SizedBox(height: 12),
              Text(
                "Not found in source: ${result.faithfulness.ungrounded.join(', ')}",
                style: theme.textTheme.bodySmall
                    ?.copyWith(color: theme.colorScheme.error),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _chip(BuildContext context, IconData icon, String label,
      {bool warn = false}) {
    final theme = Theme.of(context);
    return Chip(
      avatar: Icon(icon,
          size: 18,
          color: warn ? theme.colorScheme.error : theme.colorScheme.primary),
      label: Text(label),
      backgroundColor: theme.colorScheme.surface,
    );
  }
}
