# Legal Document Summarization — Full Stack

A **FastAPI** backend that summarizes legal/compliance documents with the pretrained
`facebook/bart-large-cnn` model (same model and logic as the Colab notebook), and a
**Flutter** frontend that lets a user paste a document, hit *Summarize*, and read the result.

```
project/
├── backend/     # FastAPI + BART summarization service
└── frontend/    # Flutter app (paste text → summary)
```

## Architecture at a glance

```
 Flutter app  ──HTTP POST /summarize──▶  FastAPI  ──▶  BART (bart-large-cnn)
 (text input)                            (loads model once at startup)
      ▲                                        │
      └──────────  JSON: summary + metadata ◀──┘
```

- The backend loads the model **once** at startup (FastAPI lifespan), so requests are fast.
- Long documents are handled with **map-reduce chunking** (they exceed BART's 1024-token window).
- Each response includes the summary plus metadata: token counts, compression ratio, whether the
  document was chunked, and a lightweight **faithfulness** check (facts in the summary that
  weren't found in the source).

## Quick start

**1. Backend** (see `backend/README.md` for detail)
```bash
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
First boot downloads the model (~1.6 GB), then: open http://localhost:8000/docs

**2. Frontend** (see `frontend/README.md` for detail)
```bash
cd frontend
flutter pub get
flutter run
```
Set the backend URL in `lib/config.dart` to match where you run the app (Android emulator uses
`http://10.0.2.2:8000`; web/desktop/iOS-sim use `http://localhost:8000`).

## Note on models
No fine-tuning — the assessment doesn't require it. `bart-large-cnn` is BART already fine-tuned
for summarization, used via transfer learning. It's tuned on news, so the register is slightly
off-domain for legal text; this is called out honestly in the write-up, and the faithfulness
check guards the high-stakes-legal requirement.
